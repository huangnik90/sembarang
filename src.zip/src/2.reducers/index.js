import {combineReducers} from 'redux'
import User from './userGlobal'

export default combineReducers({
    user : User
})
